#! C:\Users\yeshw\Desktop\Umass\Geology_497\Lab3
"""
This code prints "Hello World"

Yesh 2/19/20
"""

str1 = "Hello "
str2 = "World!"

phrase = str1 +str2

print(phrase)
